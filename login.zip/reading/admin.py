from django.contrib import admin
from .models import Reading

admin.site.register(Reading)